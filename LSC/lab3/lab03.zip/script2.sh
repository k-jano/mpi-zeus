#!/bin/bash -l

ping -c 3 home.agh.edu.pl
