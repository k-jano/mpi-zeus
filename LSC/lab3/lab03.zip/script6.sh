#!/bin/bash -l

povray Subset_Start_Frame=1 Subset_End_Frame=10 pov.ini
